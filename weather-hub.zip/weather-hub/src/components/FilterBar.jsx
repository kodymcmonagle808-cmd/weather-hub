import "./FilterBar.css";

const FILTERS = [
  { key: "all", label: "All", icon: "🌍" },
  { key: "clear", label: "Clear / Sunny", icon: "☀️" },
  { key: "cloudy", label: "Cloudy", icon: "☁️" },
  { key: "rain", label: "Rain", icon: "🌧️" },
  { key: "snow", label: "Snow / Ice", icon: "❄️" },
  { key: "storm", label: "Storms", icon: "⛈️" },
  { key: "wind", label: "Windy", icon: "💨" },
  { key: "fog", label: "Fog / Mist", icon: "🌫️" },
];

export default function FilterBar({ active, onChange }) {
  return (
    <div className="filter-bar">
      <span className="filter-label">Filter by condition:</span>
      <div className="filter-chips">
        {FILTERS.map((f) => (
          <button
            key={f.key}
            className={`filter-chip ${active === f.key ? "active" : ""}`}
            onClick={() => onChange(f.key)}
            data-category={f.key}
          >
            <span className="filter-chip-icon">{f.icon}</span>
            <span className="filter-chip-text">{f.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
