import "./EmptyState.css";

export default function EmptyState() {
  return (
    <div className="empty-state">
      <div className="empty-icon">⛅</div>
      <h2 className="empty-title">Search for a city to get started</h2>
      <p className="empty-desc">
        Compare weather forecasts from <strong>6 different weather sources</strong> side-by-side
        for any location. See where they agree, where they disagree, and filter by condition type.
        For US cities, includes the <strong>National Weather Service</strong> with detailed forecasts.
      </p>
      <div className="empty-models">
        <div className="em-model"><span className="em-dot" style={{background:"#0ea5e9"}} /> NWS <span className="em-org">US National Weather Service</span></div>
        <div className="em-model"><span className="em-dot" style={{background:"#3b82f6"}} /> ECMWF <span className="em-org">EU</span></div>
        <div className="em-model"><span className="em-dot" style={{background:"#ef4444"}} /> GFS / NOAA <span className="em-org">US</span></div>
        <div className="em-model"><span className="em-dot" style={{background:"#f59e0b"}} /> ICON / DWD <span className="em-org">Germany</span></div>
        <div className="em-model"><span className="em-dot" style={{background:"#10b981"}} /> GEM / ECCC <span className="em-org">Canada</span></div>
        <div className="em-model"><span className="em-dot" style={{background:"#8b5cf6"}} /> JMA <span className="em-org">Japan</span></div>
      </div>
    </div>
  );
}
