import { useState } from "react";
import { getCategoryIcon, getCategoryColor } from "../weatherApi";
import "./LocationCard.css";

function windDirLabel(deg) {
  if (deg == null) return "—";
  const dirs = ["N","NNE","NE","ENE","E","ESE","SE","SSE","S","SSW","SW","WSW","W","WNW","NW","NNW"];
  return dirs[Math.round(deg / 22.5) % 16] || "—";
}

function AgreementBadge({ results }) {
  if (results.length < 2) return null;
  const cats = results.map((r) => r.current.category);
  const unique = [...new Set(cats)];

  if (unique.length === 1)
    return <span className="agreement-badge agree">✓ All sources agree</span>;
  if (unique.length <= 2 && results.length >= 3)
    return <span className="agreement-badge mostly">~ Mostly agree</span>;
  return <span className="agreement-badge disagree">⚡ Sources disagree</span>;
}

function TempRange({ results, convertTemp, tempUnit }) {
  if (results.length === 0) return null;
  const temps = results.map((r) => r.current.temp).filter((t) => t != null);
  if (temps.length === 0) return null;
  const min = Math.min(...temps);
  const max = Math.max(...temps);
  const spread = max - min;

  return (
    <div className="temp-range">
      <span className="temp-range-label">Temp spread:</span>
      <span className="temp-range-val">
        {convertTemp(min)}° — {convertTemp(max)}°{tempUnit}
      </span>
      {spread > 5 && (
        <span className="temp-range-warn">
          ({spread > 10 ? "⚠️ high" : "moderate"} disagreement)
        </span>
      )}
    </div>
  );
}

function ConditionSummary({ results }) {
  // Group sources by what condition they report
  const groups = {};
  results.forEach((r) => {
    const cat = r.current.category;
    if (!groups[cat]) groups[cat] = [];
    groups[cat].push(r.model.name);
  });

  const entries = Object.entries(groups);
  if (entries.length <= 1) return null;

  return (
    <div className="condition-summary">
      <span className="cs-label">Who says what:</span>
      <div className="cs-items">
        {entries.map(([cat, models]) => (
          <div key={cat} className="cs-item">
            <span className="cs-icon">{getCategoryIcon(cat)}</span>
            <span className="cs-cat">{cat}</span>
            <span className="cs-dash">→</span>
            <span className="cs-models">{models.join(", ")}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export default function LocationCard({
  entry,
  enabledSources,
  convertTemp,
  tempUnit,
  onRemove,
  onRefresh,
}) {
  const { location, results, loading, error } = entry;
  const [expanded, setExpanded] = useState(false);

  const visibleResults = results.filter((r) =>
    enabledSources.includes(r.model.id)
  );

  // Dominant condition
  const catCounts = {};
  visibleResults.forEach((r) => {
    const c = r.current.category;
    catCounts[c] = (catCounts[c] || 0) + 1;
  });
  const dominantCat =
    Object.entries(catCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || "cloudy";

  return (
    <div
      className="location-card"
      style={{ "--card-accent": getCategoryColor(dominantCat) }}
    >
      {/* Header */}
      <div className="lc-header">
        <div className="lc-header-left">
          <span className="lc-icon">{getCategoryIcon(dominantCat)}</span>
          <div>
            <h2 className="lc-city">{location.name}</h2>
            <p className="lc-region">
              {[location.region, location.country].filter(Boolean).join(", ")}
            </p>
          </div>
        </div>
        <div className="lc-header-right">
          <AgreementBadge results={visibleResults} />
          <button className="lc-action" onClick={onRefresh} title="Refresh">🔄</button>
          <button className="lc-action" onClick={onRemove} title="Remove">✕</button>
        </div>
      </div>

      {/* Loading */}
      {loading && (
        <div className="lc-loading">
          <span className="lc-loading-spinner" />
          Fetching from {location.countryCode === "US" ? "6" : "5"} weather sources for {location.name}…
        </div>
      )}

      {/* Error */}
      {error && (
        <div className="lc-error">
          ⚠️ Error: {error} <button onClick={onRefresh}>Retry</button>
        </div>
      )}

      {/* Results */}
      {!loading && !error && visibleResults.length > 0 && (
        <>
          <TempRange results={visibleResults} convertTemp={convertTemp} tempUnit={tempUnit} />
          <ConditionSummary results={visibleResults} />

          <div className="lc-sources">
            {visibleResults.map((r) => (
              <div
                key={r.model.id}
                className={`source-card ${r.source === "nws" ? "source-card-nws" : ""}`}
                style={{ "--src-color": r.model.color }}
              >
                <div className="sc-header">
                  <span className="sc-dot" style={{ background: r.model.color }} />
                  <span className="sc-model">{r.model.name}</span>
                  <span className="sc-org">{r.model.org}</span>
                </div>

                <div className="sc-main">
                  <span className="sc-condition-icon">
                    {getCategoryIcon(r.current.category)}
                  </span>
                  <span className="sc-temp">
                    {r.current.temp != null ? `${convertTemp(r.current.temp)}°` : "—"}
                  </span>
                </div>

                <div className="sc-condition">{r.current.condition}</div>

                {/* NWS detailed forecast */}
                {r.source === "nws" && r.current.detailedForecast && (
                  <div className="sc-nws-detail">
                    <span className="sc-nws-label">NWS Forecast:</span>
                    {r.current.detailedForecast}
                  </div>
                )}

                <div className="sc-details">
                  <div className="sc-detail">
                    <span className="sc-detail-label">Feels like</span>
                    <span className="sc-detail-val">
                      {r.current.feelsLike != null ? `${convertTemp(r.current.feelsLike)}°${tempUnit}` : "—"}
                    </span>
                  </div>
                  <div className="sc-detail">
                    <span className="sc-detail-label">Wind</span>
                    <span className="sc-detail-val">
                      {r.current.windSpeed != null ? `${r.current.windSpeed} mph ${windDirLabel(r.current.windDir)}` : "—"}
                    </span>
                  </div>
                  <div className="sc-detail">
                    <span className="sc-detail-label">Humidity</span>
                    <span className="sc-detail-val">
                      {r.current.humidity != null ? `${r.current.humidity}%` : "—"}
                    </span>
                  </div>

                  {expanded && (
                    <>
                      <div className="sc-detail">
                        <span className="sc-detail-label">Gusts</span>
                        <span className="sc-detail-val">
                          {r.current.windGusts ? `${r.current.windGusts} mph` : "—"}
                        </span>
                      </div>
                      <div className="sc-detail">
                        <span className="sc-detail-label">Precip</span>
                        <span className="sc-detail-val">
                          {r.current.precipitation != null ? `${r.current.precipitation}"` : "—"}
                        </span>
                      </div>
                      <div className="sc-detail">
                        <span className="sc-detail-label">Cloud</span>
                        <span className="sc-detail-val">
                          {r.current.cloudCover != null ? `${r.current.cloudCover}%` : "—"}
                        </span>
                      </div>
                      <div className="sc-detail">
                        <span className="sc-detail-label">Pressure</span>
                        <span className="sc-detail-val">
                          {r.current.pressure ? `${Math.round(r.current.pressure)} hPa` : "—"}
                        </span>
                      </div>
                    </>
                  )}
                </div>

                {/* NWS upcoming periods */}
                {expanded && r.source === "nws" && r.current.nwsPeriods?.length > 1 && (
                  <div className="sc-nws-periods">
                    <span className="sc-nws-periods-title">Upcoming:</span>
                    {r.current.nwsPeriods.slice(1).map((p, i) => (
                      <div key={i} className="sc-nws-period">
                        <span className="sc-nws-period-name">{p.name}</span>
                        <span className="sc-nws-period-temp">{p.temperature}°{p.temperatureUnit}</span>
                        <span className="sc-nws-period-cond">{p.shortForecast}</span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>

          <button className="lc-expand" onClick={() => setExpanded((e) => !e)}>
            {expanded ? "Show less ▲" : "Show more details ▼"}
          </button>
        </>
      )}

      {!loading && !error && visibleResults.length === 0 && (
        <div className="lc-empty">
          No results match the current filter / source selection.
        </div>
      )}
    </div>
  );
}
