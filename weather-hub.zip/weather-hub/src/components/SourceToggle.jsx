import "./SourceToggle.css";

export default function SourceToggle({ models, enabled, onToggle }) {
  return (
    <div className="source-toggle">
      <span className="source-label">Sources:</span>
      <div className="source-chips">
        {models.map((m) => {
          const isOn = enabled.includes(m.id);
          return (
            <button
              key={m.id}
              className={`source-chip ${isOn ? "active" : ""}`}
              style={{
                "--src-color": m.color,
                borderColor: isOn ? m.color : undefined,
                background: isOn ? `${m.color}18` : undefined,
              }}
              onClick={() => onToggle(m.id)}
              title={m.org}
            >
              <span
                className="source-dot"
                style={{ background: isOn ? m.color : "var(--text-muted)" }}
              />
              <span className="source-name">{m.name}</span>
              <span className="source-org">{m.org}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}
