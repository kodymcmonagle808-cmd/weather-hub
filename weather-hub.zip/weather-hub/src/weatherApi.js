/**
 * Weather API utility
 *
 * Fetches forecasts from MULTIPLE real weather sources for the SAME location:
 *
 * Via Open-Meteo (free, no key):
 *   - ECMWF IFS   → European Centre for Medium-Range Weather Forecasts
 *   - GFS          → NOAA Global Forecast System (US)
 *   - ICON         → DWD / German Weather Service
 *   - GEM          → Environment and Climate Change Canada
 *   - JMA          → Japan Meteorological Agency
 *
 * Direct API (free, no key, US only):
 *   - NWS          → National Weather Service (api.weather.gov)
 *
 * Each source runs its own simulations, so they can DISAGREE on temperature,
 * conditions, wind, etc. — that's the whole point of the app.
 */

// ── WMO weather code decoder ──────────────────────────────────
const WMO_CODES = {
  0: { label: "Clear sky", cat: "clear" },
  1: { label: "Mainly clear", cat: "clear" },
  2: { label: "Partly cloudy", cat: "cloudy" },
  3: { label: "Overcast", cat: "cloudy" },
  45: { label: "Fog", cat: "fog" },
  48: { label: "Depositing rime fog", cat: "fog" },
  51: { label: "Light drizzle", cat: "rain" },
  53: { label: "Moderate drizzle", cat: "rain" },
  55: { label: "Dense drizzle", cat: "rain" },
  56: { label: "Light freezing drizzle", cat: "rain" },
  57: { label: "Dense freezing drizzle", cat: "rain" },
  61: { label: "Slight rain", cat: "rain" },
  63: { label: "Moderate rain", cat: "rain" },
  65: { label: "Heavy rain", cat: "rain" },
  66: { label: "Light freezing rain", cat: "rain" },
  67: { label: "Heavy freezing rain", cat: "rain" },
  71: { label: "Slight snow fall", cat: "snow" },
  73: { label: "Moderate snow fall", cat: "snow" },
  75: { label: "Heavy snow fall", cat: "snow" },
  77: { label: "Snow grains", cat: "snow" },
  80: { label: "Slight rain showers", cat: "rain" },
  81: { label: "Moderate rain showers", cat: "rain" },
  82: { label: "Violent rain showers", cat: "rain" },
  85: { label: "Slight snow showers", cat: "snow" },
  86: { label: "Heavy snow showers", cat: "snow" },
  95: { label: "Thunderstorm", cat: "storm" },
  96: { label: "Thunderstorm w/ slight hail", cat: "storm" },
  99: { label: "Thunderstorm w/ heavy hail", cat: "storm" },
};

export function decodeWeatherCode(code) {
  return WMO_CODES[code] || { label: "Unknown", cat: "cloudy" };
}

// ── All weather sources ───────────────────────────────────────
export const WEATHER_MODELS = [
  { id: "nws", name: "NWS", org: "National Weather Service (US)", color: "#0ea5e9", type: "direct" },
  { id: "ecmwf_ifs025", name: "ECMWF", org: "European Centre (EU)", color: "#3b82f6", type: "open-meteo" },
  { id: "gfs_seamless", name: "GFS / NOAA", org: "NOAA Global Forecast (US)", color: "#ef4444", type: "open-meteo" },
  { id: "icon_seamless", name: "ICON / DWD", org: "German Weather Service", color: "#f59e0b", type: "open-meteo" },
  { id: "gem_seamless", name: "GEM / ECCC", org: "Environment Canada", color: "#10b981", type: "open-meteo" },
  { id: "jma_seamless", name: "JMA", org: "Japan Meteorological Agency", color: "#8b5cf6", type: "open-meteo" },
];

// ── Geocoding (location search) ───────────────────────────────
export async function searchLocations(query) {
  if (!query || query.trim().length < 2) return [];
  const url = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query)}&count=8&language=en&format=json`;
  const res = await fetch(url);
  if (!res.ok) throw new Error("Geocoding failed");
  const data = await res.json();
  return (data.results || []).map((r) => ({
    id: r.id,
    name: r.name,
    region: r.admin1 || "",
    country: r.country || "",
    countryCode: r.country_code || "",
    lat: r.latitude,
    lon: r.longitude,
    label: [r.name, r.admin1, r.country_code].filter(Boolean).join(", "),
  }));
}

// ── Open-Meteo: fetch one model ───────────────────────────────
async function fetchOpenMeteoModel(lat, lon, modelId) {
  const params = new URLSearchParams({
    latitude: lat,
    longitude: lon,
    current: [
      "temperature_2m",
      "relative_humidity_2m",
      "apparent_temperature",
      "weather_code",
      "wind_speed_10m",
      "wind_gusts_10m",
      "wind_direction_10m",
      "precipitation",
      "cloud_cover",
      "pressure_msl",
    ].join(","),
    hourly: "temperature_2m,weather_code,precipitation_probability,wind_speed_10m",
    forecast_days: 1,
    models: modelId,
    temperature_unit: "fahrenheit",
    wind_speed_unit: "mph",
    precipitation_unit: "inch",
  });

  const url = `https://api.open-meteo.com/v1/forecast?${params}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Open-Meteo ${modelId} failed`);
  return res.json();
}

// ── NWS: fetch National Weather Service (US only) ─────────────
function classifyNwsForecast(forecast) {
  const s = (forecast || "").toLowerCase();
  if (s.includes("snow") || s.includes("blizzard") || s.includes("flurr") || s.includes("sleet") || s.includes("ice pellet") || s.includes("freezing")) return "snow";
  if (s.includes("thunder") || s.includes("tornado") || s.includes("hurricane") || s.includes("severe")) return "storm";
  if (s.includes("rain") || s.includes("drizzle") || s.includes("shower")) return "rain";
  if (s.includes("fog") || s.includes("mist") || s.includes("haze") || s.includes("smoke")) return "fog";
  if (s.includes("wind") || s.includes("breezy") || s.includes("gust")) return "wind";
  if (s.includes("sunny") || s.includes("clear") || s.includes("fair")) return "clear";
  if (s.includes("cloud") || s.includes("overcast") || s.includes("partly")) return "cloudy";
  return "cloudy";
}

async function fetchNWS(lat, lon) {
  // Step 1: get the forecast grid endpoint for this lat/lon
  const pointRes = await fetch(
    `https://api.weather.gov/points/${lat.toFixed(4)},${lon.toFixed(4)}`,
    { headers: { "User-Agent": "WeatherHub/1.0 (github.com)" } }
  );
  if (!pointRes.ok) throw new Error("NWS point lookup failed");
  const pointData = await pointRes.json();

  const forecastUrl = pointData.properties?.forecast;
  const observationStationsUrl = pointData.properties?.observationStations;

  if (!forecastUrl) throw new Error("NWS has no forecast for this location");

  // Step 2: fetch current observation from nearest station
  let currentTemp = null;
  let currentWind = null;
  let currentWindDir = null;
  let currentGusts = null;
  let currentHumidity = null;
  let currentDescription = "";
  let currentPressure = null;

  if (observationStationsUrl) {
    try {
      const stationsRes = await fetch(observationStationsUrl, {
        headers: { "User-Agent": "WeatherHub/1.0 (github.com)" },
      });
      if (stationsRes.ok) {
        const stationsData = await stationsRes.json();
        const stationId = stationsData.features?.[0]?.properties?.stationIdentifier;
        if (stationId) {
          const obsRes = await fetch(
            `https://api.weather.gov/stations/${stationId}/observations/latest`,
            { headers: { "User-Agent": "WeatherHub/1.0 (github.com)" } }
          );
          if (obsRes.ok) {
            const obsData = await obsRes.json();
            const props = obsData.properties || {};
            if (props.temperature?.value != null) {
              currentTemp = Math.round(props.temperature.value * 9 / 5 + 32);
            }
            if (props.windSpeed?.value != null) {
              currentWind = Math.round(props.windSpeed.value * 0.621371);
            }
            if (props.windDirection?.value != null) {
              currentWindDir = props.windDirection.value;
            }
            if (props.windGust?.value != null) {
              currentGusts = Math.round(props.windGust.value * 0.621371);
            }
            if (props.relativeHumidity?.value != null) {
              currentHumidity = Math.round(props.relativeHumidity.value);
            }
            if (props.barometricPressure?.value != null) {
              currentPressure = Math.round(props.barometricPressure.value / 100);
            }
            currentDescription = props.textDescription || "";
          }
        }
      }
    } catch {
      // observation fetch is optional
    }
  }

  // Step 3: fetch the text forecast
  const forecastRes = await fetch(forecastUrl, {
    headers: { "User-Agent": "WeatherHub/1.0 (github.com)" },
  });
  if (!forecastRes.ok) throw new Error("NWS forecast fetch failed");
  const forecastData = await forecastRes.json();
  const periods = forecastData.properties?.periods || [];
  const now = periods[0] || {};

  const conditionText = currentDescription || now.shortForecast || "Unknown";
  const category = classifyNwsForecast(conditionText);
  const temp = currentTemp ?? now.temperature ?? null;

  return {
    temp,
    feelsLike: temp,
    humidity: currentHumidity,
    windSpeed: currentWind ?? (now.windSpeed ? parseInt(now.windSpeed) : null),
    windGusts: currentGusts ?? 0,
    windDir: currentWindDir ?? 0,
    precipitation: 0,
    cloudCover: null,
    pressure: currentPressure,
    weatherCode: null,
    condition: conditionText,
    category,
    detailedForecast: now.detailedForecast || "",
    nwsPeriods: periods.slice(0, 6),
  };
}

// ── Fetch ALL sources for one location ────────────────────────
export async function fetchAllModelsWeather(lat, lon, countryCode) {
  const isUS = (countryCode || "").toUpperCase() === "US";

  const tasks = WEATHER_MODELS.map(async (model) => {
    try {
      if (model.id === "nws") {
        if (!isUS) return null; // NWS only covers the US
        const current = await fetchNWS(lat, lon);
        return { model, current, hourly: null, source: "nws" };
      }

      const data = await fetchOpenMeteoModel(lat, lon, model.id);
      const raw = data.current || {};
      const decoded = decodeWeatherCode(raw.weather_code);

      let category = decoded.cat;
      if (raw.wind_speed_10m > 25 && category === "clear") {
        category = "wind";
      }

      return {
        model,
        current: {
          temp: Math.round(raw.temperature_2m),
          feelsLike: Math.round(raw.apparent_temperature),
          humidity: raw.relative_humidity_2m,
          windSpeed: Math.round(raw.wind_speed_10m),
          windGusts: Math.round(raw.wind_gusts_10m || 0),
          windDir: raw.wind_direction_10m,
          precipitation: raw.precipitation,
          cloudCover: raw.cloud_cover,
          pressure: raw.pressure_msl,
          weatherCode: raw.weather_code,
          condition: decoded.label,
          category,
        },
        hourly: data.hourly || null,
        source: "open-meteo",
      };
    } catch (err) {
      console.warn(`Failed to fetch ${model.name}:`, err.message);
      return null;
    }
  });

  const results = await Promise.all(tasks);
  return results.filter(Boolean);
}

// ── Helpers ───────────────────────────────────────────────────

export function getCategoryIcon(cat) {
  const icons = {
    snow: "❄️", rain: "🌧️", storm: "⛈️", clear: "☀️",
    cloudy: "☁️", wind: "💨", fog: "🌫️",
  };
  return icons[cat] || "🌡️";
}

export function getCategoryColor(cat) {
  const colors = {
    snow: "#a5d8ff", rain: "#4dabf7", storm: "#845ef7", clear: "#fcc419",
    cloudy: "#868e96", wind: "#38d9a9", fog: "#adb5bd",
  };
  return colors[cat] || "#868e96";
}
