import { useState, useCallback } from "react";
import SearchBar from "./components/SearchBar";
import FilterBar from "./components/FilterBar";
import LocationCard from "./components/LocationCard";
import SourceToggle from "./components/SourceToggle";
import EmptyState from "./components/EmptyState";
import { fetchAllModelsWeather, WEATHER_MODELS } from "./weatherApi";
import "./App.css";

export default function App() {
  // Each entry: { location, results[], loading, error }
  const [locations, setLocations] = useState([]);
  const [activeFilter, setActiveFilter] = useState("all");
  const [enabledSources, setEnabledSources] = useState(
    WEATHER_MODELS.map((m) => m.id)
  );
  const [tempUnit, setTempUnit] = useState("F"); // F or C

  const addLocation = useCallback(
    async (loc) => {
      // Don't add duplicates
      if (locations.some((l) => l.location.id === loc.id)) return;

      const entry = { location: loc, results: [], loading: true, error: null };
      setLocations((prev) => [entry, ...prev]);

      try {
        const results = await fetchAllModelsWeather(loc.lat, loc.lon, loc.countryCode);
        setLocations((prev) =>
          prev.map((l) =>
            l.location.id === loc.id ? { ...l, results, loading: false } : l
          )
        );
      } catch (err) {
        setLocations((prev) =>
          prev.map((l) =>
            l.location.id === loc.id
              ? { ...l, loading: false, error: err.message }
              : l
          )
        );
      }
    },
    [locations]
  );

  const removeLocation = useCallback((id) => {
    setLocations((prev) => prev.filter((l) => l.location.id !== id));
  }, []);

  const refreshLocation = useCallback(async (loc) => {
    setLocations((prev) =>
      prev.map((l) =>
        l.location.id === loc.id ? { ...l, loading: true, error: null } : l
      )
    );
    try {
      const results = await fetchAllModelsWeather(loc.lat, loc.lon, loc.countryCode);
      setLocations((prev) =>
        prev.map((l) =>
          l.location.id === loc.id ? { ...l, results, loading: false } : l
        )
      );
    } catch (err) {
      setLocations((prev) =>
        prev.map((l) =>
          l.location.id === loc.id
            ? { ...l, loading: false, error: err.message }
            : l
        )
      );
    }
  }, []);

  const toggleSource = useCallback((modelId) => {
    setEnabledSources((prev) =>
      prev.includes(modelId)
        ? prev.filter((id) => id !== modelId)
        : [...prev, modelId]
    );
  }, []);

  const convertTemp = (f) => {
    if (tempUnit === "C") return Math.round(((f - 32) * 5) / 9);
    return f;
  };

  // Filter locations by active condition
  const filteredLocations = locations.map((entry) => {
    if (activeFilter === "all") return entry;
    const filtered = entry.results.filter(
      (r) => r.current.category === activeFilter
    );
    return { ...entry, results: filtered };
  });

  return (
    <div className="app">
      <header className="app-header">
        <div className="header-top">
          <div className="brand">
            <span className="brand-icon">⛅</span>
            <div>
              <h1 className="brand-title">Weather Hub</h1>
              <p className="brand-sub">
                Compare forecasts across weather models
              </p>
            </div>
          </div>
          <div className="header-controls">
            <button
              className={`unit-btn ${tempUnit === "F" ? "active" : ""}`}
              onClick={() => setTempUnit("F")}
            >
              °F
            </button>
            <button
              className={`unit-btn ${tempUnit === "C" ? "active" : ""}`}
              onClick={() => setTempUnit("C")}
            >
              °C
            </button>
          </div>
        </div>
        <SearchBar onSelect={addLocation} />
        <SourceToggle
          models={WEATHER_MODELS}
          enabled={enabledSources}
          onToggle={toggleSource}
        />
        <FilterBar active={activeFilter} onChange={setActiveFilter} />
      </header>

      <main className="app-main">
        {locations.length === 0 ? (
          <EmptyState />
        ) : (
          <div className="locations-grid">
            {filteredLocations.map((entry) => (
              <LocationCard
                key={entry.location.id}
                entry={entry}
                enabledSources={enabledSources}
                convertTemp={convertTemp}
                tempUnit={tempUnit}
                onRemove={() => removeLocation(entry.location.id)}
                onRefresh={() => refreshLocation(entry.location)}
              />
            ))}
          </div>
        )}
      </main>

      <footer className="app-footer">
        <p>
          Data from{" "}
          <a href="https://open-meteo.com/" target="_blank" rel="noreferrer">
            Open-Meteo
          </a>{" "}
          (ECMWF, GFS, ICON, GEM, JMA) &amp;{" "}
          <a href="https://www.weather.gov/" target="_blank" rel="noreferrer">
            NWS / weather.gov
          </a>
          . Free &amp; open-source — no API keys needed.
        </p>
      </footer>
    </div>
  );
}
