# ⛅ Weather Hub

**Compare weather forecasts from 5 real weather models side-by-side.** See where they agree, where they disagree, and filter by condition type (snow, rain, storms, etc.).

![Weather Hub Screenshot](https://img.shields.io/badge/Status-Working-brightgreen) ![License](https://img.shields.io/badge/License-MIT-blue)

## What It Does

Most weather apps give you a single forecast. But different weather services use different computational models, and they often **disagree** — especially about precipitation, storms, and edge-case conditions.

Weather Hub queries **5 real forecast models** via the [Open-Meteo API](https://open-meteo.com/) (free, no API key) and displays them side-by-side so you can:

- **Compare temperatures** — see the spread across models
- **Compare conditions** — does ECMWF say rain while GFS says clear?
- **Filter by condition** — show only locations with snow, storms, etc.
- **Toggle sources on/off** — focus on the models you trust
- **Track multiple cities** — add as many locations as you want

### Weather Models Compared

| Model | Source | Organization |
|-------|--------|-------------|
| **ECMWF IFS** | 🔵 | European Centre for Medium-Range Weather Forecasts (EU) |
| **GFS** | 🔴 | Global Forecast System — NOAA (US) |
| **ICON** | 🟡 | DWD — German Weather Service |
| **GEM** | 🟢 | ECCC — Environment and Climate Change Canada |
| **JMA** | 🟣 | Japan Meteorological Agency |

## Quick Start

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/weather-hub.git
cd weather-hub

# Install dependencies
npm install

# Start dev server
npm run dev
```

Opens at [http://localhost:3000](http://localhost:3000).

## Build for Production

```bash
npm run build
npm run preview
```

The `dist/` folder is ready to deploy to Vercel, Netlify, GitHub Pages, etc.

## Tech Stack

- **React 18** — UI framework
- **Vite** — build tool & dev server
- **Open-Meteo API** — free weather data (no API key required)
- **Vanilla CSS** — no UI library, fully custom dark theme

## Project Structure

```
weather-hub/
├── src/
│   ├── components/
│   │   ├── SearchBar.jsx/.css    # City search with autocomplete
│   │   ├── FilterBar.jsx/.css    # Condition type filter chips
│   │   ├── SourceToggle.jsx/.css # Toggle weather models on/off
│   │   ├── LocationCard.jsx/.css # Per-city multi-source comparison
│   │   └── EmptyState.jsx/.css   # Landing state
│   ├── weatherApi.js             # Open-Meteo API + WMO code decoder
│   ├── App.jsx / App.css         # Main layout & state
│   ├── main.jsx                  # React entry
│   └── index.css                 # Global styles & CSS vars
├── index.html
├── vite.config.js
├── package.json
└── README.md
```

## Features

- 🔍 **City search** with autocomplete (Open-Meteo geocoding)
- 📊 **5 forecast models** compared side-by-side
- ❄️ **Condition filters** — Snow, Rain, Storms, Clear, Cloudy, Wind, Fog
- 🔀 **Source toggles** — enable/disable specific models
- 🌡️ **°F / °C toggle**
- ✅ **Agreement indicator** — see if models agree or disagree
- 📈 **Temperature spread** — see how much models differ
- 📱 **Responsive** — works on mobile

## How It Works

Open-Meteo provides access to multiple global numerical weather prediction models. Each model independently simulates atmospheric conditions using different algorithms, resolutions, and initial data. This app queries all 5 in parallel and presents the results in a unified comparison view.

WMO weather codes are decoded into human-readable conditions and categorized (snow, rain, storm, clear, cloudy, wind, fog) for filtering.

## License

MIT — do whatever you want with it.
